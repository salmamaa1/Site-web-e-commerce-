<?php
session_start();
include 'connexion.php';

if (!empty($_GET['id'])) {
    $idCategorie = $_GET['id'];

    // Vérifiez si la catégorie a des articles associés (assurez-vous d'adapter cette requête en fonction de votre structure de base de données)
    $sqlArticles = "SELECT COUNT(*) FROM articles WHERE id_categorie = ?";
    $reqArticles = $connexion->prepare($sqlArticles);
    $reqArticles->execute([$idCategorie]);
    $nbArticles = $reqArticles->fetchColumn();

    if ($nbArticles == 0) {
        // Pas d'articles associés, suppression de la catégorie
        $sqlDelete = "DELETE FROM categorie_article WHERE id = ?";
        $reqDelete = $connexion->prepare($sqlDelete);
        $reqDelete->execute([$idCategorie]);

        if ($reqDelete->rowCount() != 0) {
            $_SESSION['message']['text'] = "Catégorie supprimée avec succès";
            $_SESSION['message']['type'] = "success";
        } else {
            $_SESSION['message']['text'] = "Erreur lors de la suppression de la catégorie";
            $_SESSION['message']['type'] = "danger";
        }
    } else {
        // Des articles sont associés à la catégorie, informez l'utilisateur
        $_SESSION['message']['text'] = "Impossible de supprimer la catégorie. Des articles y sont associés.";
        $_SESSION['message']['type'] = "warning";
    }
} else {
    $_SESSION['message']['text'] = "ID de catégorie non fourni pour la suppression.";
    $_SESSION['message']['type'] = "danger";
}

header('Location: ../vue/categorie.php');
?>
